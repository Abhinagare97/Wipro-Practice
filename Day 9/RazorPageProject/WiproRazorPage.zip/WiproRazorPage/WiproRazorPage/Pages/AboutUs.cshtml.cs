using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace WiproRazorPage.Pages
{
    public class WiproModel : PageModel
    {

        public void OnGet()
        {
            
        }
    }
}
